package ar.edu.unlam.pb2.parcial1;

public class Actores {
 private String nombre;
 public Actores(String nombre) {
	 this.nombre= nombre;
 }
public String getNombre() {
	return nombre;
}
public void setNombre(String nombre) {
	this.nombre = nombre;
}
 
}
